<x-guest-layout>
    <x-auth-card>
        <x-slot name="logo">
            <a href="/">
                <x-application-logo class="w-20 h-20 fill-current text-gray-500" />
            </a>
        </x-slot>

        <!-- Validation Errors -->
        <x-auth-validation-errors class="mb-4" :errors="$errors" />

        <form method="POST" action="{{ route('register') }}">
            @csrf

            <!-- Name -->
            <div>
                <x-label for="name" :value="__('Name')" />
                <x-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus />
            </div>

            <!-- Email Address -->
            <div class="mt-4">
                <x-label for="email" :value="__('Email')" />
                <x-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required />
            </div>

            <!-- Role -->
            <div class="mt-4">
                <x-label for="role_id" :value="__('Role')" />
                <select id="role_id" name="role_id" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                    @foreach($roles as $role)
                        <option value="{{ $role->id }}">{{ $role->name }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Organization Selection -->
            <div class="mt-4">
                <div class="flex items-center">
                    <input id="create_organization" type="checkbox" name="create_organization" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" onchange="toggleOrganizationFields()">
                    <label for="create_organization" class="ml-2 block text-sm text-gray-900">{{ __('Create a new organization') }}</label>
                </div>
            </div>

            <!-- New Organization Fields (Hidden by default) -->
            <div id="new_organization_fields" class="mt-4 hidden">
                <x-label for="organization_name" :value="__('Organization Name')" />
                <x-input id="organization_name" class="block mt-1 w-full" type="text" name="organization_name" :value="old('organization_name')" />

                <x-label for="organization_description" :value="__('Organization Description')" class="mt-2" />
                <textarea id="organization_description" name="organization_description" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">{{ old('organization_description') }}</textarea>
            </div>

            <!-- Existing Organization Selection (Shown by default) -->
            <div id="existing_organization_fields" class="mt-4">
                <x-label for="organization_id" :value="__('Select Organization')" />
                <select id="organization_id" name="organization_id" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                    <option value="">{{ __('No Organization') }}</option>
                    @foreach(\App\Models\Organization::all() as $organization)
                        <option value="{{ $organization->id }}">{{ $organization->name }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-label for="password" :value="__('Password')" />
                <x-input id="password" class="block mt-1 w-full" type="password" name="password" required autocomplete="new-password" />
            </div>

            <!-- Confirm Password -->
            <div class="mt-4">
                <x-label for="password_confirmation" :value="__('Confirm Password')" />
                <x-input id="password_confirmation" class="block mt-1 w-full" type="password" name="password_confirmation" required />
            </div>

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('login') }}">
                    {{ __('Already registered?') }}
                </a>

                <x-button class="ml-4">
                    {{ __('Register') }}
                </x-button>
            </div>
        </form>

        <script>
            function toggleOrganizationFields() {
                const createOrgCheckbox = document.getElementById('create_organization');
                const newOrgFields = document.getElementById('new_organization_fields');
                const existingOrgFields = document.getElementById('existing_organization_fields');

                if (createOrgCheckbox.checked) {
                    newOrgFields.classList.remove('hidden');
                    existingOrgFields.classList.add('hidden');
                } else {
                    newOrgFields.classList.add('hidden');
                    existingOrgFields.classList.remove('hidden');
                }
            }
        </script>
    </x-auth-card>
</x-guest-layout>
