<x-guest-layout>
    <x-auth-card>
        <x-slot name="logo">
            <a href="/">
                <x-application-logo class="w-20 h-20 fill-current text-gray-500" />
            </a>
        </x-slot>

        <div class="mb-4 text-center">
            <h2 class="text-xl font-bold text-gray-700">{{ __('Accept Invitation') }}</h2>
            <p class="mt-2 text-sm text-gray-600">
                {{ __('You have been invited to join') }} <span class="font-semibold">{{ $invitation->organization->name }}</span> {{ __('as a') }} <span class="font-semibold">{{ $invitation->role->name }}</span>.
            </p>
            <p class="mt-2 text-sm text-gray-500">
                {{ __('Please complete the form below to create your account.') }}
            </p>
        </div>

        <!-- Validation Errors -->
        <x-auth-validation-errors class="mb-4" :errors="$errors" />

        <form method="POST" action="{{ route('invitations.process', $invitation->token) }}">
            @csrf

            <!-- Name -->
            <div>
                <x-label for="name" :value="__('Name')" />
                <x-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus />
            </div>

            <!-- Email (read-only) -->
            <div class="mt-4">
                <x-label for="email" :value="__('Email')" />
                <x-input id="email" class="block mt-1 w-full bg-gray-100" type="email" name="email" :value="$invitation->email" readonly />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-label for="password" :value="__('Password')" />
                <x-input id="password" class="block mt-1 w-full" type="password" name="password" required autocomplete="new-password" />
            </div>

            <!-- Confirm Password -->
            <div class="mt-4">
                <x-label for="password_confirmation" :value="__('Confirm Password')" />
                <x-input id="password_confirmation" class="block mt-1 w-full" type="password" name="password_confirmation" required />
            </div>

            <div class="flex items-center justify-end mt-4">
                <x-button class="ml-4">
                    {{ __('Accept Invitation') }}
                </x-button>
            </div>
        </form>
    </x-auth-card>
</x-guest-layout>
