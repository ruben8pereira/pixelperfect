<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ $report->title }}
            </h2>
            <div class="flex space-x-2">
                <a href="{{ route('reports.edit', $report) }}" class="inline-flex items-center px-4 py-2 bg-amber-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-amber-700 active:bg-amber-800 focus:outline-none focus:border-amber-800 focus:ring ring-amber-300 disabled:opacity-25 transition ease-in-out duration-150">
                    Edit Report
                </a>
                <a href="{{ route('reports.export-pdf', $report) }}" class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-700 active:bg-green-800 focus:outline-none focus:border-green-800 focus:ring ring-green-300 disabled:opacity-25 transition ease-in-out duration-150">
                    Export PDF
                </a>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Report Info Section -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="col-span-2">
                            <h3 class="text-lg font-medium text-gray-900 mb-2">Report Details</h3>
                            <p class="text-gray-700 mb-4">{{ $report->description }}</p>

                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <p class="text-gray-500">Created By</p>
                                    <p class="font-medium">{{ $report->creator->name }}</p>
                                </div>
                                <div>
                                    <p class="text-gray-500">Organization</p>
                                    <p class="font-medium">{{ $report->organization->name }}</p>
                                </div>
                                <div>
                                    <p class="text-gray-500">Created On</p>
                                    <p class="font-medium">{{ $report->created_at->format('M d, Y H:i') }}</p>
                                </div>
                                <div>
                                    <p class="text-gray-500">Language</p>
                                    <p class="font-medium">
                                        @if($report->language == 'en')
                                            English
                                        @elseif($report->language == 'fr')
                                            French
                                        @elseif($report->language == 'de')
                                            German
                                        @else
                                            {{ $report->language }}
                                        @endif
                                    </p>
                                </div>
                                <div>
                                    <p class="text-gray-500">PDF Exports</p>
                                    <p class="font-medium">{{ $report->pdf_export_count }}</p>
                                </div>
                            </div>
                        </div>

                        <div class="border-l pl-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-2">Report Status</h3>

                            <div class="mt-2">
                                <div class="mb-2">
                                    <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                                        {{ $report->reportDefects->count() }} Defects
                                    </span>
                                </div>

                                <div class="mb-2">
                                    <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                                        {{ $report->reportImages->count() }} Images
                                    </span>
                                </div>

                                <div>
                                    <span class="px-2 py-1 text-xs rounded-full bg-purple-100 text-purple-800">
                                        {{ $report->reportComments->count() }} Comments
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Defects Section -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Defects</h3>

                    @forelse($report->reportDefects as $index => $defect)
                        <div class="mb-6 pb-6 {{ !$loop->last ? 'border-b border-gray-200' : '' }}">
                            <div class="flex justify-between items-start">
                                <div class="flex items-center">
                                    <span class="bg-gray-200 text-gray-700 font-bold py-1 px-3 rounded-full text-sm mr-3">
                                        #{{ $index + 1 }}
                                    </span>
                                    <h4 class="text-md font-medium">{{ $defect->defectType->name }}</h4>
                                </div>
                                <span class="{{
                                    $defect->severity == 'low' ? 'bg-green-100 text-green-800' :
                                    ($defect->severity == 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                    ($defect->severity == 'high' ? 'bg-orange-100 text-orange-800' :
                                    'bg-red-100 text-red-800'))
                                }} px-2 py-1 rounded-full text-xs">
                                    {{ ucfirst($defect->severity) }}
                                </span>
                            </div>

                            <div class="mt-2">
                                <p class="text-gray-700">{{ $defect->description }}</p>
                            </div>

                            @if($defect->coordinates)
                                <div class="mt-2 grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <p class="text-gray-500">Location</p>
                                        <p class="font-medium">
                                            Lat: {{ $defect->coordinates['latitude'] ?? 'N/A' }},
                                            Lng: {{ $defect->coordinates['longitude'] ?? 'N/A' }}
                                        </p>
                                    </div>
                                </div>
                            @endif
                        </div>
                    @empty
                        <div class="bg-gray-50 p-4 rounded-md">
                            <p class="text-gray-600">No defects have been recorded for this report.</p>
                        </div>
                    @endforelse
                </div>
            </div>

            <!-- Images Section -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Images</h3>

                    @if($report->reportImages->count() > 0)
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            @foreach($report->reportImages as $image)
                                <div class="border rounded-lg overflow-hidden">
                                    <img src="{{ asset('storage/' . $image->file_path) }}" alt="Report Image" class="w-full h-48 object-cover">
                                    @if($image->caption)
                                        <div class="p-2 text-sm text-gray-700">
                                            {{ $image->caption }}
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="bg-gray-50 p-4 rounded-md">
                            <p class="text-gray-600">No images have been uploaded for this report.</p>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Comments Section -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Comments</h3>

                    @if($report->reportComments->count() > 0)
                        <div class="space-y-4 mb-6">
                            @foreach($report->reportComments as $comment)
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium">{{ $comment->user->name }}</p>
                                            <p class="text-sm text-gray-500">{{ $comment->created_at->format('M d, Y H:i') }}</p>
                                        </div>
                                        @if($comment->include_in_pdf)
                                            <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                                                Included in PDF
                                            </span>
                                        @else
                                            <span class="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full">
                                                Not in PDF
                                            </span>
                                        @endif
                                    </div>
                                    <div class="mt-2">
                                        <p class="text-gray-700">{{ $comment->content }}</p>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="bg-gray-50 p-4 rounded-md mb-6">
                            <p class="text-gray-600">No comments have been added to this report.</p>
                        </div>
                    @endif

                    <!-- Add Comment Form -->
                    <form action="{{ route('reports.comments.store', $report) }}" method="POST">
                        @csrf
                        <div class="mb-4">
                            <x-label for="content" :value="__('Add Comment')" />
                            <textarea id="content" name="content" rows="3" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full" required></textarea>
                        </div>

                        <div class="flex items-center">
                            <label class="flex items-center">
                                <input type="checkbox" name="include_in_pdf" value="1" checked class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                <span class="ml-2 text-sm text-gray-600">{{ __('Include in PDF export') }}</span>
                            </label>

                            <x-button class="ml-auto">
                                {{ __('Add Comment') }}
                            </x-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
