<!-- Language Field -->
<div class="mb-4">
    <x-label for="language" :value="__('Report Language')" />
    <select id="language" name="language" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full">
        <option value="en" {{ old('language') == 'en' ? 'selected' : '' }}>English</option>
        <option value="fr" {{ old('language') == 'fr' ? 'selected' : '' }}>French</option>
        <option value="de" {{ old('language') == 'de' ? 'selected' : '' }}>German</option>
    </select>
</div>
</div>

<!-- Right Column -->
<div>
<!-- Image Upload -->
<div class="mb-4">
    <x-label for="images" :value="__('Images')" />
    <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
        <div class="space-y-1 text-center">
            <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <div class="flex text-sm text-gray-600">
                <label for="images" class="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none">
                    <span>Upload images</span>
                    <input id="images" name="images[]" type="file" class="sr-only" multiple accept="image/*">
                </label>
                <p class="pl-1">or drag and drop</p>
            </div>
            <p class="text-xs text-gray-500">
                PNG, JPG, GIF up to 10MB
            </p>
        </div>
    </div>
</div>

<!-- Defects Section -->
<div class="mb-4">
    <x-label :value="__('Defects')" />
    <div class="mt-2 p-4 border border-gray-200 rounded-md">
        <div id="defects-container">
            <div class="defect-item mb-4 pb-4 border-b border-gray-200">
                <div class="flex items-center justify-between mb-2">
                    <h4 class="font-medium">Defect #1</h4>
                    <button type="button" class="text-gray-400 hover:text-gray-500" onclick="removeDefect(this)" disabled>
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <x-label for="defects[0][defect_type_id]" :value="__('Defect Type')" />
                        <select name="defects[0][defect_type_id]" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full" required>
                            <option value="">Select Type</option>
                            @foreach(\App\Models\DefectType::all() as $defectType)
                                <option value="{{ $defectType->id }}">
                                    {{ $defectType->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <x-label for="defects[0][severity]" :value="__('Severity')" />
                        <select name="defects[0][severity]" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full">
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                            <option value="critical">Critical</option>
                        </select>
                    </div>
                </div>

                <div class="mt-2">
                    <x-label for="defects[0][description]" :value="__('Description')" />
                    <textarea name="defects[0][description]" rows="2" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full"></textarea>
                </div>

                <div class="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <x-label for="defects[0][coordinates][latitude]" :value="__('Latitude')" />
                        <x-input name="defects[0][coordinates][latitude]" type="text" class="block mt-1 w-full" placeholder="e.g. 45.123456" />
                    </div>
                    <div>
                        <x-label for="defects[0][coordinates][longitude]" :value="__('Longitude')" />
                        <x-input name="defects[0][coordinates][longitude]" type="text" class="block mt-1 w-full" placeholder="e.g. -73.123456" />
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-2">
            <button type="button" onclick="addDefect()" class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-xs text-gray-800 uppercase tracking-widest hover:bg-gray-300 active:bg-gray-400 focus:outline-none focus:border-gray-500 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                Add Another Defect
            </button>
        </div>
    </div>
</div>
</div>
</div>

<div class="flex justify-end mt-6">
<a href="{{ route('reports.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-xs text-gray-800 uppercase tracking-widest hover:bg-gray-300 active:bg-gray-400 focus:outline-none focus:border-gray-500 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150 mr-2">
Cancel
</a>
<x-button>
{{ __('Create Report') }}
</x-button>
</div>


<x-app-layout>
<x-slot name="header">
<h2 class="font-semibold text-xl text-gray-800 leading-tight">
{{ __('Create New Report') }}
</h2>
</x-slot>

<div class="py-12">
<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
<div class="p-6 bg-white border-b border-gray-200">

@if ($errors->any())
<div class="mb-4 bg-red-50 p-4 rounded-md">
<div class="font-medium text-red-600">{{ __('Whoops! Something went wrong.') }}</div>
<ul class="mt-3 list-disc list-inside text-sm text-red-600">
@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif

<form action="{{ route('reports.store') }}" method="POST" enctype="multipart/form-data">
@csrf

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
<!-- Left Column -->
<div>
<!-- Title Field -->
<div class="mb-4">
    <x-label for="title" :value="__('Report Title')" />
    <x-input id="title" class="block mt-1 w-full" type="text" name="title" :value="old('title')" required autofocus />
</div>

<!-- Description Field -->
<div class="mb-4">
    <x-label for="description" :value="__('Description')" />
    <textarea id="description" name="description" rows="4" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full">{{ old('description') }}</textarea>
</div>

<!-- Organization Field - Only for Admins -->
@if(auth()->user()->role->name == 'Administrator')
    <div class="mb-4">
        <x-label for="organization_id" :value="__('Organization')" />
        <select id="organization_id" name="organization_id" class="rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 block mt-1 w-full" required>
            <option value="">Select Organization</option>
            @foreach(\App\Models\Organization::all() as $organization)
                <option value="{{ $organization->id }}" {{ old('organization_id') == $organization->id ? 'selected' : '' }}>
                    {{ $organization->name }}
                </option>
            @endforeach
        </select>
    </div>
@endif
