<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Stats Cards -->
                        @if(auth()->user()->role->name == 'Administrator')
                            <div class="bg-blue-50 p-4 rounded-lg shadow">
                                <h3 class="text-blue-700 font-semibold">Organizations</h3>
                                <p class="text-3xl font-bold">{{ $organizations }}</p>
                            </div>
                        @endif

                        @if(auth()->user()->role->name == 'Administrator' || auth()->user()->role->name == 'Organization')
                            <div class="bg-green-50 p-4 rounded-lg shadow">
                                <h3 class="text-green-700 font-semibold">Users</h3>
                                <p class="text-3xl font-bold">{{ $users }}</p>
                            </div>
                        @endif

                        <div class="bg-purple-50 p-4 rounded-lg shadow">
                            <h3 class="text-purple-700 font-semibold">Reports</h3>
                            <p class="text-3xl font-bold">{{ $reports }}</p>
                        </div>

                        @if(auth()->user()->role->name == 'Organization')
                            <div class="bg-amber-50 p-4 rounded-lg shadow">
                                <h3 class="text-amber-700 font-semibold">Organization</h3>
                                <p class="text-xl font-semibold">{{ auth()->user()->organization->name }}</p>
                            </div>
                        @endif
                    </div>

                    <!-- Recent Reports Section -->
                    <div class="mt-8">
                        <h3 class="text-lg font-semibold mb-4">Recent Reports</h3>

                        @if(count($recent_reports) > 0)
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                            @if(auth()->user()->role->name == 'Administrator')
                                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Organization</th>
                                            @endif
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Defects</th>
                                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        @foreach($recent_reports as $report)
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-medium text-gray-900">{{ $report->title }}</div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm text-gray-500">{{ $report->created_at->format('M d, Y') }}</div>
                                                </td>
                                                @if(auth()->user()->role->name == 'Administrator')
                                                    <td class="px-6 py-4 whitespace-nowrap">
                                                        <div class="text-sm text-gray-500">{{ $report->organization->name }}</div>
                                                    </td>
                                                @endif
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm text-gray-500">{{ $report->reportDefects->count() }}</div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                    <a href="{{ route('reports.show', $report) }}" class="text-indigo-600 hover:text-indigo-900 mr-3">View</a>
                                                    <a href="{{ route('reports.edit', $report) }}" class="text-amber-600 hover:text-amber-900 mr-3">Edit</a>
                                                    <a href="{{ route('reports.export-pdf', $report) }}" class="text-green-600 hover:text-green-900">PDF</a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <div class="bg-gray-50 p-4 rounded-md">
                                <p class="text-gray-600">No reports found.
                                    @if(auth()->user()->role->name != 'BasicUser')
                                        <a href="{{ route('reports.create') }}" class="text-indigo-600 hover:underline">Create your first report</a>.
                                    @endif
                                </p>
                            </div>
                        @endif
                    </div>

                    @if(auth()->user()->role->name != 'BasicUser')
                        <div class="mt-6">
                            <a href="{{ route('reports.create') }}" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300 disabled:opacity-25 transition ease-in-out duration-150">
                                New Report
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
