<?php

namespace App\Actions;

use App\Models\User;
use App\Models\Organization;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class CreateNewUser
{
    public function create(array $input)
    {
        Validator::make($input, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'role_id' => ['required', 'exists:roles,id'],
            'create_organization' => ['sometimes', 'boolean'],
            'organization_name' => ['required_if:create_organization,1', 'string', 'max:255'],
            'organization_id' => ['required_if:create_organization,0', 'nullable', 'exists:organizations,id'],
        ])->validate();

        // Create organization if needed
        $organizationId = null;
        if (!empty($input['create_organization']) && $input['create_organization']) {
            $organization = Organization::create([
                'name' => $input['organization_name'],
                'description' => $input['organization_description'] ?? null,
            ]);
            $organizationId = $organization->id;
        } else {
            $organizationId = $input['organization_id'] ?? null;
        }

        return User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
            'role_id' => $input['role_id'],
            'organization_id' => $organizationId,
            'is_validated' => false, // New users need validation
        ]);
    }
}
